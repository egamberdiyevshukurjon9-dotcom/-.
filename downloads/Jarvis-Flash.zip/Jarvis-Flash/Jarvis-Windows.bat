@echo off
set "F=%~dp0Jarvis.html"
for %%P in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe") do (
  if exist %%P (start "" %%P "%F%" & exit /b)
)
start "" msedge "%F%"
