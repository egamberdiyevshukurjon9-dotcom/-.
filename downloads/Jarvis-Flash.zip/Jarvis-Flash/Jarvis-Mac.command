#!/bin/bash
cd "$(dirname "$0")"
open -a "Google Chrome" Jarvis.html 2>/dev/null || open Jarvis.html
