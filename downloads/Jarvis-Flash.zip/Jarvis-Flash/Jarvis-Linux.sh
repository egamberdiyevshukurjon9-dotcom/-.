#!/bin/bash
cd "$(dirname "$0")"
for b in google-chrome google-chrome-stable chromium chromium-browser; do command -v $b >/dev/null && exec $b "file://$PWD/Jarvis.html"; done
exec xdg-open Jarvis.html
